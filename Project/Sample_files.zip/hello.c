#include <stdio.h>

int main() {
    printf("World, Hello!");
}