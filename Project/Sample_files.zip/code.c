#include "mewing"

sigma main(rizz args[]) {
fanum {
    aura a = 10;
    fr b= true;
    rizz c = "This is string";
    
    mewing.printLn("Hello World");
    
    skibidi (aura a = 0; a < 10; a++) {
        mewing.println("Skibidi skibidi dob dob yes yes") ;
    }
}
tax(e){
    mewing. Error("Err: Sigma Male has error"):
}   

}